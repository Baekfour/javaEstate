import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.opencsv.exceptions.CsvValidationException;

public class Main {
	public static void main(String[] args) throws CsvValidationException, IOException {
		// TODO Auto-generated method stub
		Process process = new Process();
		process.process();
	}
}
